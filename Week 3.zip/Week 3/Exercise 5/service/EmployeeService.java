package com.example.EmployeeManagement.service;
import com.example.EmployeeManagement.model.Employee;
import java.util.List;

public interface EmployeeService {

    List<Employee> getAllEmployees();

    Employee getEmployeeById(Long id);

    List<Employee> getEmployeesByName(String name);

    Employee getEmployeeByNameCustom(String name);

    Employee getEmployeeByEmailCustom(String email);

    Employee saveEmployee(Employee employee);

    Employee updateEmployee(Long id, Employee employee);

    void deleteEmployee(Long id);
}
