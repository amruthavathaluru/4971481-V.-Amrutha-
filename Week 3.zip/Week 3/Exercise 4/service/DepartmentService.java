package com.example.EmployeeManagement.service;

import com.example.EmployeeManagement.model.Department;

import java.util.List;

public interface DepartmentService {

    Department saveDepartment(Department department);

    List<Department> getAllDepartments();

    Department getDepartmentById(Long id);

    Department updateDepartment(Long id, Department departmentDetails);

    void deleteDepartment(Long id);
}
