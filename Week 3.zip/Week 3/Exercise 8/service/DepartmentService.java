package com.example.EmployeeManagement.service;

import com.example.EmployeeManagement.model.Department;
import com.example.EmployeeManagement.repository.DepartmentProjection;
import java.util.List;

public interface DepartmentService {

    List<Department> getAllDepartments();
    Department getDepartmentById(Long id);
    Department saveDepartment(Department department);
    Department updateDepartment(Long id, Department department);
    void deleteDepartment(Long id);

    // New method for projection
    List<DepartmentProjection> getDepartmentsByName(String name);
}
