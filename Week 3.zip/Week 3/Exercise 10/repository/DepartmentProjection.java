package com.example.EmployeeManagement.repository;

public interface DepartmentProjection {
    Long getId();
    String getName();
}
