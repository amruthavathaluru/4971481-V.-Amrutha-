package com.example.EmployeeManagement.repository;

public interface EmployeeProjection {

    Long getId();

    String getName();
}
