package com.example.EmployeeManagement.repository.secondary;

import com.example.EmployeeManagement.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    List<Department> findByName(String name);  // Add this method if it doesn't exist

}
