package com.example.EmployeeManagement.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.DataSourceBuilder;
import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Autowired
    private Environment env;

    @Bean(name = "primaryDataSource")
    public DataSource primaryDataSource() {
        return DataSourceBuilder.create()
                .driverClassName(env.getProperty("spring.datasource.primary.driver-class-name"))
                .url(env.getProperty("spring.datasource.primary.url"))
                .username(env.getProperty("spring.datasource.primary.username"))
                .password(env.getProperty("spring.datasource.primary.password"))
                .build();
    }

    @Bean(name = "secondaryDataSource")
    public DataSource secondaryDataSource() {
        return DataSourceBuilder.create()
                .driverClassName(env.getProperty("spring.datasource.secondary.driver-class-name"))
                .url(env.getProperty("spring.datasource.secondary.url"))
                .username(env.getProperty("spring.datasource.secondary.username"))
                .password(env.getProperty("spring.datasource.secondary.password"))
                .build();
    }
}
