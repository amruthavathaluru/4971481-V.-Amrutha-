package com.example.EmployeeManagement.service;

import com.example.EmployeeManagement.model.Employee;
import com.example.EmployeeManagement.repository.primary.EmployeeRepository;
import com.example.EmployeeManagement.repository.EmployeeProjection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public Page<Employee> getAllEmployees(Pageable pageable) {
        return employeeRepository.findAll(pageable);
    }

    @Override
    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    @Override
    public List<EmployeeProjection> getEmployeesByName(String name) {
        return employeeRepository.findByNameProjection(name);
    }

    @Override
    public Employee getEmployeeByNameCustom(String name) {
        return employeeRepository.findByNameCustom(name);
    }

    @Override
    public Employee getEmployeeByEmailCustom(String email) {
        return employeeRepository.findByEmail(email);
    }

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public Employee updateEmployee(Long id, Employee employee) {
        if (employeeRepository.existsById(id)) {
            employee.setId(id);
            return employeeRepository.save(employee);
        } else {
            return null; // or throw an exception
        }
    }

    @Override
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    @Override
    public void saveEmployeesInBatch(List<Employee> employees) {
        employeeRepository.saveAll(employees);
    }
}
