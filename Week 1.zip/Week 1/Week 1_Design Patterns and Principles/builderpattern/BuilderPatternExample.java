public class BuilderPatternExample {
    public static void main(String[] args) {
        // Create a computer with specific configurations using the Builder
        Computer gamingPC = new Computer.Builder()
                .setCPU("Intel i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setPowerSupply("750W")
                .setCoolingSystem("Liquid Cooling")
                .build();

        Computer officePC = new Computer.Builder()
                .setCPU("Intel i5")
                .setRAM("16GB")
                .setStorage("512GB SSD")
                .setGraphicsCard("Integrated")
                .setPowerSupply("500W")
                .build();

        System.out.println(gamingPC);
        System.out.println(officePC);
    }
}
