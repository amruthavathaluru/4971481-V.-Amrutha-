public class StrategyPatternExample {
    public static void main(String[] args) {
        // Create payment strategies
        PaymentStrategy creditCard = new CreditCardPayment("1234-5678-9876-5432");
        PaymentStrategy paypal = new PayPalPayment("user@example.com");

        // Create context and execute payments
        PaymentContext context = new PaymentContext(creditCard);
        context.executePayment(250.75);

        context = new PaymentContext(paypal);
        context.executePayment(99.99);
    }
}
