public class AdapterPatternExample {
    public static void main(String[] args) {
        // Create instances of the third-party payment gateways
        PayPalPaymentGateway payPalPaymentGateway = new PayPalPaymentGateway();
        StripePaymentGateway stripePaymentGateway = new StripePaymentGateway();

        // Create adapters for the payment gateways
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalPaymentGateway);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripePaymentGateway);

        // Use the adapters to process payments
        payPalAdapter.processPayment(150.75);
        stripeAdapter.processPayment(200.50);
    }
}
