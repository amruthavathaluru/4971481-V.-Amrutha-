public class ProxyPatternExample {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        // The image is loaded and displayed on the first request
        image1.display();

        // The image is already loaded, so it is displayed directly
        image1.display();

        // The image is loaded and displayed on the first request
        image2.display();
    }
}
