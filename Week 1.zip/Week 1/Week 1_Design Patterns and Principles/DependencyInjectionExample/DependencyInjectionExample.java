public class DependencyInjectionExample {
    public static void main(String[] args) {
        // Create a concrete repository
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Inject repository into service
        CustomerService customerService = new CustomerService(customerRepository);

        // Use the service to find a customer
        String customer = customerService.getCustomer(1);
        System.out.println("Found Customer: " + customer);
    }
}
