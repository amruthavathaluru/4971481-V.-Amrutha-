import java.util.HashMap;
import java.util.Map;

public class FinancialForecastingOptimized {

    // Memoization map to store previously calculated values
    private static Map<Integer, Double> memo = new HashMap<>();

    // Recursive method to calculate future value with memoization
    public static double futureValue(double P, double r, int n) {
        // Base case: if n is 0, return the principal amount P
        if (n == 0) {
            return P;
        }
        // Check if the value is already computed
        if (memo.containsKey(n)) {
            return memo.get(n);
        }
        // Recursive case: calculate the future value for n-1 and then multiply by (1 + r)
        double result = futureValue(P, r, n - 1) * (1 + r);
        memo.put(n, result); // Store the result in the memo map
        return result;
    }

    public static void main(String[] args) {
        double principal = 1000; // Initial amount
        double rate = 0.05; // Growth rate
        int periods = 10; // Number of periods

        double futureValue = futureValue(principal, rate, periods);
        System.out.println("Future Value after " + periods + " periods: " + futureValue);
    }
}
