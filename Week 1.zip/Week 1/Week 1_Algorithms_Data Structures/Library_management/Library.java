import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Library {

    // Linear search to find books by title
    public static Book linearSearchByTitle(List<Book> books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    // Binary search to find books by title (assuming the list is sorted)
    public static Book binarySearchByTitle(List<Book> books, String title) {
        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Book midBook = books.get(mid);
            int comparison = midBook.getTitle().compareToIgnoreCase(title);

            if (comparison == 0) {
                return midBook;
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        List<Book> books = new ArrayList<>(List.of(
            new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book(2, "To Kill a Mockingbird", "Harper Lee"),
            new Book(3, "1984", "George Orwell")
        ));

        // Linear search example
        String searchTitleLinear = "1984";
        Book foundBookLinear = linearSearchByTitle(books, searchTitleLinear);
        System.out.println(foundBookLinear != null ? "Book found (Linear): " + foundBookLinear : "Book not found (Linear)");

        // Sort the books by title for binary search
        Collections.sort(books, Comparator.comparing(Book::getTitle));

        // Binary search example
        String searchTitleBinary = "1984";
        Book foundBookBinary = binarySearchByTitle(books, searchTitleBinary);
        System.out.println(foundBookBinary != null ? "Book found (Binary): " + foundBookBinary : "Book not found (Binary)");
    }
}
