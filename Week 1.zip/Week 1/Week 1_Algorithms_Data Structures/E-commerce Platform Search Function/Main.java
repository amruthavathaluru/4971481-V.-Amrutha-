import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Phone", "Electronics"),
            new Product(3, "Shirt", "Apparel")
        };

        // Linear Search
        int index = LinearSearch.linearSearch(products, 2);
        System.out.println("Linear Search - Product found at index: " + index);

        // Binary Search - Requires sorted array
        Arrays.sort(products, (p1, p2) -> Integer.compare(p1.productId, p2.productId));
        index = BinarySearch.binarySearch(products, 2);
        System.out.println("Binary Search - Product found at index: " + index);
    }
}
