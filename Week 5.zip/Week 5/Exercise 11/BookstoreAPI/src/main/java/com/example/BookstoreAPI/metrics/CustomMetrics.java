package com.example.BookstoreAPI.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Timer;
import org.springframework.stereotype.Component;

@Component
public class CustomMetrics {

    private final Counter customCounter;
    private final Timer customTimer;

    public CustomMetrics(MeterRegistry meterRegistry) {
        // Initialize custom counter
        customCounter = meterRegistry.counter("custom.counter", "description", "A custom counter metric");

        // Initialize custom timer
        customTimer = meterRegistry.timer("custom.timer", "description", "A custom timer metric");
    }

    public void incrementCustomCounter() {
        customCounter.increment();
    }

    public void recordCustomTimer(Runnable action) {
        customTimer.record(action);
    }
}
