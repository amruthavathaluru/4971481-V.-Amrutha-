package com.example.BookstoreAPI.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Version;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter  // Lombok annotation to generate getter methods
@Setter  // Lombok annotation to generate setter methods
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Primary key field

    private String title;
    private String author;
    private Double price;

    @Version
    private int version;  // For optimistic locking, if needed
}
