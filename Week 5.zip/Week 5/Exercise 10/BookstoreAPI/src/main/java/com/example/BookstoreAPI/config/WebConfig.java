package com.example.BookstoreAPI.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.http.MediaType;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
        configurer.favorParameter(true) // Use URL parameters for content negotiation
                  .parameterName("mediaType") // Parameter name for media type
                  .ignoreAcceptHeader(false) // Do not ignore Accept header
                  .defaultContentType(MediaType.APPLICATION_JSON) // Default content type
                  .mediaType("json", MediaType.APPLICATION_JSON) // Media type for JSON
                  .mediaType("xml", MediaType.APPLICATION_XML); // Media type for XML
    }
}
